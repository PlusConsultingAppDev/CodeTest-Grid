﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using ProductDataApp.Infrastructure.Repository;

namespace ProductDataApp.Controllers
{
    public class ProductController : ApiController
    {
        private readonly IUnitOfWork _unitOfWork;

        public ProductController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IHttpActionResult GetProductData()
        {
            try
            {
                var products = _unitOfWork.ProductRepository.Get(null, null, string.Empty);
                return Content(HttpStatusCode.OK, products);
            }
            catch (Exception ex)
            {
                var message = $"Source:\t{ex.Source}\nMessage:\t{ex.Message}";
                throw new HttpResponseException(Request.CreateErrorResponse(HttpStatusCode.InternalServerError, message));
            }
        }
    }
}
