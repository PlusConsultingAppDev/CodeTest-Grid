using Microsoft.Practices.Unity;
using System.Web.Http;
using ProductDataApp.Infrastructure.Repository;
using Unity.WebApi;

namespace ProductDataApp
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            container.RegisterType<IUnitOfWork, UnitOfWork>();
    
            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}