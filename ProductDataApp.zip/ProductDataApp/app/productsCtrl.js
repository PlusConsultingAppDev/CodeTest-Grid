﻿var productsCtrl = function ($scope, $http) {
    $scope.products = [];

    getProducts();

    function getProducts() {
        $http.get("api/Product/GetProductData")
        .then(function(results) {
            $scope.products = results.data;
        });
    }
};
productsCtrl.$inject = ["$scope", "$http"];
appMain.controller("productsCtrl", productsCtrl);