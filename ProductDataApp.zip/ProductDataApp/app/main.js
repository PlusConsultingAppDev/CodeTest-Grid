﻿var appMain = angular.module("appMain", ["ngRoute", "ngSanitize", "ui.grid"]);

var mainConfig = function($routeProvider, $locationProvider) {
    $routeProvider
        .when("/",
        {
            templateUrl: "app/index.html",
            controller: "productsCtrl"
        });
    $locationProvider.html5Mode({
        enabled: true,
        requireBase: false
    });
}
mainConfig.$inject = ["$routeProvider", "$locationProvider"];
appMain.config(mainConfig);