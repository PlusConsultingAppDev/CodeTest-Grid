﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using ProductDataApp.Infrastructure.Data;
using ProductDataApp.Models;

namespace ProductDataApp.Infrastructure.Repository
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AdventureWorks2012Entities _context;

        public UnitOfWork(AdventureWorks2012Entities context)
        {
            _context = context;
           ProductRepository = new Repository<Product>(_context);
        }

        public DbContext Context => _context;

        public IRepository<Product> ProductRepository { get; }

        public void Save()
        {
            _context.SaveChanges();
        }

        private bool _disposed;

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            _disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}