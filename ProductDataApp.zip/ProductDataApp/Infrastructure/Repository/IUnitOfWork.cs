﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProductDataApp.Models;

namespace ProductDataApp.Infrastructure.Repository
{
    public interface IUnitOfWork : IDisposable
    {
        IRepository<Product> ProductRepository { get; }
            
        DbContext Context { get; }

        void Save();
    }
}
