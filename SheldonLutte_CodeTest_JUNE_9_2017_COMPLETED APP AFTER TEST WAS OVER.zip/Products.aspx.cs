﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public partial class Products : System.Web.UI.Page
{
	sqlDb db = new sqlDb();
	sqlDataset ds = new sqlDataset();
	HttpParms hParms = new HttpParms();

	string[] GRIDFIELDNAMES = new string[] { "Name", "ProductNumber", "Color", "SafetyStockLevel", "ReorderPoint", "StandardCost", "ListPrice" };

	//==================================================
	protected void Page_Load(object sender, EventArgs e)
	{
		//open the database for read or update
		string DbConnectionSpec = db.WebDBConnectionString("AdventureWorks");
		if (DbConnectionSpec.Length > 0)
			db.Open(DbConnectionSpec);

		if (!IsPostBack) LoadPage();
	}

	//==================================================
	protected void Page_UnLoad(object sender, EventArgs e)
	{
		db.Close();
		db = null;
	}

	//==================================================
	public void LoadPage()
	{
		//get specs from URL
		int pg = hParms.GetQueryParmInt("pg", 1);
		int sz = hParms.GetQueryParmInt("sz", 15);
		int sort = hParms.GetQueryParmInt("sort", 0);
		string filter = hParms.GetQueryParm("filter", "");
		string search = hParms.GetQueryParm("find", "");

		//---populate product grid----------------

		//create sql query to get data for current grid view
		string sql = GetProductListSQL(ref pg, ref sz, sort, filter, search);

		//populate the grid
		if (sql.Length > 0)
			db.BindRepeater(ref repProducts, sql);

		//get number of pages in current dataset
		int pgCt = ((GetRecordCount(filter, search) + sz - 1) / sz);

		//update nav controls
		btnFirst.CommandArgument = "1";
		btnPrev.CommandArgument = (pg - 1).ToString();
		btnNext.CommandArgument = (pg + 1).ToString();
		btnLast.CommandArgument = pgCt.ToString();

		spnPageNbr.InnerText = pg.ToString() + " of " + pgCt.ToString();

		//populate the search box with current search
		txtSearch.Value = search;

		//populate sort options drop down
		for(int i = 0; i < GRIDFIELDNAMES.Length; i++){
			drpSort.Items.Add(GRIDFIELDNAMES[i]);
		}
		if (Math.Abs(sort) > 0) drpSort.SelectedIndex = Math.Abs(sort) - 1;

		//populate page size options drop down
		drpPageLen.Items.Add("15");
		drpPageLen.Items.Add("25");
		drpPageLen.Items.Add("50");
		drpPageLen.Items.Add("100");
		drpPageLen.Items.Add("200");
		switch (sz)
		{
			case 15: drpPageLen.SelectedIndex = 0; break;
			case 25: drpPageLen.SelectedIndex = 1; break;
			case 50: drpPageLen.SelectedIndex = 2; break;
			case 100: drpPageLen.SelectedIndex = 3; break;
			case 200: drpPageLen.SelectedIndex = 4; break;
			default: drpPageLen.SelectedIndex = 0; break;
		}
	}

	//==================================================
	private int GetRecordCount(string filter, string search)
	{
		try
		{
			//create query for current filter and search
			string sql = GetSQLWhereClause(filter, search);
			sql = "SELECT COUNT(*) FROM Production.Product " + sql;

			//get the record count from the database, return the count
			return db.ReadFirstInt(sql);
		}
		catch { return 0; }
	}

	//==================================================
	private string GetProductListSQL(ref int pg, ref int pglen, int sortCol, string filter, string search)
	{
		//validate parms, then create sql to populate the products grid

		//---PAGE-----------------------------------------------
		if (pg < 1) pg = 1;
		if (pglen < 10) pglen = 10;

		int recordStart = (pg - 1) * pglen + 1;
		int recordEnd = recordStart + pglen;

		//---SORT-----------------------------------------------
		// "sort" indicates on which column the list is sorted. A negative value indicates sort descending.
		// ex. 1 means sort by first column, 2 = sort by second col, -2 = sort by second column descending

		bool SortDesc = (sortCol < 0);
		sortCol = Math.Abs(sortCol);

		
		// if sort = 0 (no sort selected) or is out of range, so use default sort (1st column)

		if (sortCol == 0 || sortCol > GRIDFIELDNAMES.Length)
		{
			sortCol = 1;	//default sort column
		}
		sortCol--;	//change sort spec to access 0-based array

		//---FILTER AND SEARCH-----------------------------------------------
		//convert search words from query parms to sql where snippet
		//note: filter parm in url is already in form of 'field=value'
		string sqlWhereClause = GetSQLWhereClause(filter, search);


		//---BUILD SQL-----------------------------------------------
		string sql = "SELECT * FROM (SELECT ROW_NUMBER() OVER ( ORDER BY " + GRIDFIELDNAMES[sortCol] + (SortDesc ? " DESC" : "") + " ) AS RowNum, "
			+ " Name, ProductNumber, Color, SafetyStockLevel, ReorderPoint, StandardCost, ListPrice, ProductID"
			+ " FROM Production.Product "
			+ sqlWhereClause;

		sql += ") as dat1 WHERE RowNum >= " + recordStart.ToString()
			 + " AND RowNum < " + recordEnd.ToString()
			 + " ORDER BY RowNum";

		return sql.ToString();
	}

	//==================================================
	private string GetSQLWhereClause(string filter, string search)
	{
		string sql = "";
		if (search.Trim().Length > 0)
		{
			string[] words = search.Split(' ');
			foreach (string word in words)
			{
				sql += " AND (Name LIKE '%" + word + "%'"
					+ " OR ProductNumber LIKE '%" + word + "%'"
					+ " OR Color LIKE '%" + word + "%')";
			}
			if (sql.Length > 0) sql = sql.Substring(5);
		}

		if (filter.Length > 0 && search.Length > 0)
			return " WHERE (" + filter + ") AND (" + sql + ")";
		else if (filter.Length > 0)
			return " WHERE (" + filter + ")";
		else if (search.Length > 0)
			return " WHERE (" + sql + ")";
		else
			return "";
	}


	//==================================================
	protected void repProducts_ItemDataBound(object sender, RepeaterItemEventArgs e)
	{
		if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
		{
			sqlDataset dat = new sqlDataset((System.Data.Common.DbDataRecord)(e.Item.DataItem));

			try{
				((HtmlInputHidden)e.Item.FindControl("id")).Value = dat.GetInt("ProductID").ToString();

				//clear checkbox and edit flags
				((HtmlInputCheckBox)e.Item.FindControl("chk")).Checked = false;
				((HtmlInputHidden)e.Item.FindControl("ed")).Value = "0";

				//display query record number to help visually navigate pages
				((HtmlTableCell)e.Item.FindControl("tdRecNbr")).InnerText = dat.GetInt("RowNum").ToString();

				//load data
				((HtmlInputText)e.Item.FindControl("t1")).Value = dat.GetString("Name");
				((HtmlInputText)e.Item.FindControl("t2")).Value = dat.GetString("ProductNumber");
				((HtmlInputText)e.Item.FindControl("t3")).Value = dat.GetString("Color");
				((HtmlInputText)e.Item.FindControl("t4")).Value = dat.GetInt("SafetyStockLevel").ToString();
				((HtmlInputText)e.Item.FindControl("t5")).Value = dat.GetInt("ReorderPoint").ToString();
				((HtmlInputText)e.Item.FindControl("t6")).Value = dat.GetDouble("StandardCost").ToString("0.00");
				((HtmlInputText)e.Item.FindControl("t7")).Value = dat.GetDouble("ListPrice").ToString("0.00");
			}
			catch { }
		}
	}

	//==================================================
	protected void btnSearch_Click(object sender, EventArgs e)
	{
		//alter the parms of the current url to add the new search request, then reload the page
		string url = Request.Url.ToString();
		url = hParms.SetUrlQueryParm(url, "find", txtSearch.Value);
		url = hParms.SetUrlQueryParm(url, "filter", "");
		url = hParms.SetUrlQueryParm(url, "pg", "");
		Response.Redirect(url, false);
	}

	//==================================================
	protected void btnAdd_Click(object sender, EventArgs e)
	{
		try
		{
			//get data from popup window
			string name = ((HtmlInputText)FindControl("txtAddName")).Value;
			string prod = ((HtmlInputText)FindControl("txtAddNbr")).Value;
			string colr = ((HtmlInputText)FindControl("txtAddColor")).Value;
			string stck = ((HtmlInputText)FindControl("txtAddStock")).Value;
			string reord = ((HtmlInputText)FindControl("txtAddReorder")).Value;
			string cost = ((HtmlInputText)FindControl("txtAddCost")).Value;
			string price = ((HtmlInputText)FindControl("txtAddPrice")).Value;

			string sql = "INSERT INTO Production.Product (Name, ProductNumber, Color, SafetyStockLevel, ReorderPoint, StandardCost, ListPrice, DaysToManufacture, SellStartDate)"
				+ " VALUES (" + db.TEXT(name, false, true, 50, true)
				+ ", " + db.TEXT(prod, false, true, 25, true)
				+ ", " + db.TEXT(colr, false, true, 15, true)
				+ ", " + CMath.CInt(stck, 0).ToString()
				+ ", " + CMath.CInt(reord, 0).ToString()
				+ ", " + CMath.CDouble(cost, 0).ToString()
				+ ", " + CMath.CDouble(price, 0).ToString()
				+ ", 0, " + db.DATE(DateTime.MinValue)
				+ ")";

			if (db.Exec(sql) < 1)
			{
				//display error
			}
			else
			{
				//display success
			}
		}
		catch { }

		divAdd.Style["display"] = "none";
		divFilter.Style["display"] = "none";
	}

	//==================================================
	protected void btnApplyFilter_Click(object sender, EventArgs e)
	{
		//alter the parms of the current url to add the new filter request, then reload the page
		string filter = "";
		if (txtFilterName.Value.Length > 0) filter += " AND Name LIKE '%" + txtFilterName.Value + "%'";
		if (txtFilterNbr.Value.Length > 0) filter += " AND ProductNumber LIKE '%" + txtFilterNbr.Value + "%'";
		if (txtFilterColor.Value.Length > 0) filter += " AND Color LIKE '%" + txtFilterColor.Value + "%'";
		if (txtFilterStock.Value.Length > 0) filter += " AND SafetyStockLevel " + getFilterOperation(txtFilterStock.Value);
		if (txtFilterReorder.Value.Length > 0) filter += " AND ReorderPoint " + getFilterOperation(txtFilterReorder.Value);
		if (txtFilterCost.Value.Length > 0) filter += " AND StandardCost " + getFilterOperation(txtFilterCost.Value);
		if (txtFilterPrice.Value.Length > 0) filter += " AND ListPrice " + getFilterOperation(txtFilterPrice.Value);

		if (filter.Length > 0)
		{
			//remove leading "AND" from filter list
			filter = filter.Substring(5);
			//add filter to URL query parms and reload page
			string url = Request.Url.ToString();
			url = hParms.SetUrlQueryParm(url, "filter", HttpUtility.UrlEncode(filter));
			url = hParms.SetUrlQueryParm(url, "find", "");
			url = hParms.SetUrlQueryParm(url, "pg", "");
			Response.Redirect(url, false);
		}

		divAdd.Style["display"] = "none";
		divFilter.Style["display"] = "none";
	}

	//==================================================
	private string getFilterOperation(string filter)
	{
		if (filter.Length == 0) return "";
		if (filter.Contains(',')) return "IN " + filter;
		switch (filter[0])
		{
			case '=': return filter;
			case '<': return filter;
			case '>': return filter;
		}
		return "=" + filter;
	}

	//==================================================
	protected void btnDelSelected_Click(object sender, EventArgs e)
	{
		StringBuilder IdList = new StringBuilder();

		//delete the selected items (confirm prompt has already been accepted client-side)
		//save all edits
		foreach (RepeaterItem item in repProducts.Items)
		{
			if (((HtmlInputCheckBox)item.FindControl("chk")).Checked)
			{
				int id = CMath.CInt(((HtmlInputHidden)item.FindControl("id")).Value);
				if (id > 0)
					IdList.Append(",").Append(id.ToString());
			}
		}
		if (IdList.Length > 0)
		{
			//remove leading comma in ID list and create/execute SQL to remove the items from DB
			string sql = "DELETE FROM Production.Product WHERE ProductID IN (" + IdList.Remove(0, 1) + ")";
			if (db.Exec(sql) < 1)
			{
				//display error
			}
			//reload the current page to remove deleted items
			Response.Redirect(Request.Url.ToString(), false);
		}
	}

	//==================================================
	protected void btnSave_Click(object sender, EventArgs e)
	{
		//save all edits
		foreach (RepeaterItem item in repProducts.Items)
		{
			if (((HtmlInputHidden)item.FindControl("ed")).Value == "1")
			{
				//get data from popup window
				int id = CMath.CInt(((HtmlInputHidden)item.FindControl("id")).Value);
				string name = ((HtmlInputText)item.FindControl("t1")).Value;
				string prod = ((HtmlInputText)item.FindControl("t2")).Value;
				string colr = ((HtmlInputText)item.FindControl("t3")).Value;
				int stck = CMath.CInt(((HtmlInputText)item.FindControl("t4")).Value);
				int reord = CMath.CInt(((HtmlInputText)item.FindControl("t5")).Value);
				double cost = CMath.CDouble(((HtmlInputText)item.FindControl("t6")).Value);
				double price = CMath.CDouble(((HtmlInputText)item.FindControl("t7")).Value);

				if (id > 0)
				{
					//create and execute the sql update
					string sql = "UPDATE Production.Product SET Name = " + db.TEXT(name, false, true, 50, true)
						+ ", ProductNumber = " + db.TEXT(prod, false, true, 25, true)
						+ ", Color = " + db.TEXT(colr, false, true, 15, true)
						+ ", SafetyStockLevel = " + stck.ToString()
						+ ", ReorderPoint = " + reord.ToString()
						+ ", StandardCost = " + cost.ToString()
						+ ", ListPrice = " + price.ToString()
						+ " WHERE ProductID = " + id.ToString();

					if (db.Exec(sql) < 1)
					{
						//display error
					}
					else
					{
						//display success
					}
				}
			}
		}
	}

	//==================================================
	protected void drpSort_Select(object sender, EventArgs e)
	{
		string url = Request.Url.ToString();
		url = hParms.SetUrlQueryParm(url, "sort", (drpSort.SelectedIndex + 1).ToString());
		Response.Redirect(url, false);
	}

	//==================================================
	protected void drpPageLen_Select(object sender, EventArgs e)
	{
		//get current page settings
		int pg = hParms.GetQueryParmInt("pg", 1);
		int sz = hParms.GetQueryParmInt("sz", 15);
		
		//get index of top item currently displayed
		int rec = sz * (pg - 1) + 1;

		//get new page size
		sz = CMath.CInt(drpPageLen.SelectedItem.Text);
		if (sz < 15) sz = 15;		//min page size

		//calc new page to keep current top record index
		pg = ((rec - 1) / sz) + 1;

		//reset page properties
		string url = Request.Url.ToString();
		url = hParms.SetUrlQueryParm(url, "sz", sz.ToString());
		url = hParms.SetUrlQueryParm(url, "pg", pg.ToString());

		Response.Redirect(url, false);		//note: don't end response, still need to close DB
	}

	//==================================================
	protected void btnPage_Click(object sender, EventArgs e)
	{
		string pg = ((Button)sender).CommandArgument;
		string url = Request.Url.ToString();
		url = hParms.SetUrlQueryParm(url, "pg", pg);

		Response.Redirect(url, false);		//note: don't end response, still need to close DB
	}
}