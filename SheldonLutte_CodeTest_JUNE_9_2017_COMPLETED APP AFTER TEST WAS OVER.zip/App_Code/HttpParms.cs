﻿// Copyright © 2013-2015 One 2 Three, Inc. All rights reserved. Duplication, distribution and adaptation are not permitted.
// Author: Sheldon Lutte - By contract, the intellectual property and technology of this work is solely owned by One 2 Three, Inc. Crate and Barrel has exclusive, non-transferable right to use and modify this code for internal use for an unlimited period of time.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Wrapper for handling retrieval and conversion of query parms and session parms
/// </summary>
public class HttpParms : System.Web.UI.Page
{
	public HttpParms() {	}

	//========================================
	public string GetWebConfig(string key) { return GetWebConfig(key, ""); }
	public string GetWebConfig(string key, string defaultValue)
	{
		try {
			if (System.Configuration.ConfigurationManager.AppSettings[key] == null) return defaultValue;
			return System.Configuration.ConfigurationManager.AppSettings[key];
		} catch { return defaultValue; }
	}

	//========================================
	public string GetSessionVar(string varname) { return GetSessionVar(varname, ""); }
	public string GetSessionVar(string varname, string DefaultValue)
	{
		try { if (Session[varname] != null) return Convert.ToString(Session[varname]);
		} catch { }
		return DefaultValue;
	}

	public bool GetSessionVarBool(string varname, bool DefaultValue)
	{
		try { if (Session[varname] != null) return CBoolEx(GetSessionVar(varname, ""), DefaultValue);
		} catch { }
		return DefaultValue;
	}

	public int GetSessionVarInt(string varname, int DefaultValue)
	{
		try { if (Session[varname] != null) return Convert.ToInt32(Session[varname]);
		} catch { }
		return DefaultValue;
	}

	public DateTime GetSessionVarDateTime(string varname, DateTime DefaultValue)
	{
		try { if (Session[varname] != null)  return DateTime.Parse(Session[varname].ToString());
		} catch { }
		return DefaultValue;
	}

	public object GetSessionVarObject(string varname)
	{
		try{ return (Session[varname]); } catch { }
		return null; 
	}

	public bool SetSessionVar(string name, object val)
	{
		try
		{
			Session[name] = val;
			return true;	//success
		}
		catch { }
		return false;	//failed
	}

	//========================================
	public string GetQueryParm(string name) { return GetQueryParm(name, ""); }
	public string GetQueryParm(string name, string DefaultValue)
	{
		try {
			if (System.Web.HttpContext.Current.Request.QueryString[name] == null) return DefaultValue;
			return Convert.ToString(System.Web.HttpContext.Current.Request.QueryString[name]);
		} catch { }
		return DefaultValue; 
	}

	public int GetQueryParmInt(string name) { return GetQueryParmInt(name, 0); }
	public int GetQueryParmInt(string name, int DefaultValue)
	{
		try { return Convert.ToInt32(System.Web.HttpContext.Current.Request.QueryString[name].ToString()); }
		catch { }
		return DefaultValue; 
	}

	public bool GetQueryParmBool(string name, bool DefaultValue)
	{
		try { return CBoolEx(System.Web.HttpContext.Current.Request.QueryString[name].ToString().Trim().ToUpper(), DefaultValue); }
		catch { }
		return DefaultValue; 
	}

	public DateTime GetQueryParmDateTime(string name, DateTime DefaultValue)
	{
		try { return DateTime.Parse(System.Web.HttpContext.Current.Request.QueryString[name].ToString()); }
		catch { }
		return DefaultValue; 
	}

	//========================================
	public string SetUrlQueryParm(string url, string key, string value)
	{
		url = url.Trim();
		key = key.Trim();

		//make value html-safe
		value = value.Trim();
		value = value.Replace("&", "&amp;");
		//value = value.Replace(" ", "&#20%;");

		//find the key in the url
		int KeyEnd = -1;
		int KeyPos = -1;

		int iParmList = url.IndexOf("?");
		if (iParmList > -1)
		{
			//WARNING! THIS DOES NOT HANDLE QUOTED STRINGS IN PARMS
			KeyPos = url.IndexOf("?" + key + "=", iParmList);
			if (KeyPos == -1) KeyPos = url.IndexOf("&" + key + "=", iParmList);

			//find end of key
			if (KeyPos > -1)
			{
				KeyEnd = url.IndexOf('&', KeyPos + 1);
				if (KeyEnd == -1) KeyEnd = url.Length;
			}
		}

		//remove key if value is blank
		if (value.Length == 0)
		{
			if (KeyPos == -1)				//key not found, return url
				return url;
			else if (KeyEnd >= url.Length)		//key was found, remove it
				return url.Substring(0, KeyPos);
			else
				return url.Substring(0, KeyPos + 1) + url.Substring(KeyEnd + 1);
		}
		//if key not found in url, append to end
		else if (KeyPos == -1)
		{
			if (iParmList == -1)
				return url + "?" + key + "=" + value;
			else
				return url + "&" + key + "=" + value;
		}
		//key was found in url, replace it
		else
		{
			KeyPos += key.Length + 2;		//add to char pos to include "&", key and "="
			if (KeyEnd >= url.Length)
				return url.Substring(0, KeyPos) + value;
			else
				return url.Substring(0, KeyPos) + value + url.Substring(KeyEnd);
		}

		/*/separate parms from url
		n = url.IndexOf("?");
		if (n > -1)
		{
			if (n < url.Length - 1) parms = url.Substring(n + 1).Split('&');
			url = url.Substring(0, n);
		}

		if (parms != null)
		{
			foreach (string p in parms)
			{
				n = p.IndexOf('=');
				if (n == -1)
					newparms += "&" + p;
				else if (p.Substring(0, n).Equals(key, StringComparison.OrdinalIgnoreCase))
				{
					if (value.Length > 0)
						newparms += "&" + key + "=" + value;
					KeyFound = true;
				}
				else
					newparms += "&" + p;
			}
		}
		//remove leading "&"
		if (newparms.Length > 0) newparms = newparms.Substring(1);


		//reassemble url and parms list
		if (KeyFound)
			return url + "?" + newparms;
		else if (value.Length > 0)
		{
			if (newparms.Length == 0)
				return url + "?" + key + "=" + value;
			else
				return url + "?" + newparms + "&" + key + "=" + value;
		}
		else
		{
			if (newparms.Length == 0)
				return url;
			else
				return url + "?" + newparms;
		}*/
	}

	//========================================
	public string GetCookie(string key) { return GetCookie(key, ""); }
	public string GetCookie(string key, string DefaultValue)
	{
		try
		{
			if (Request.Cookies[key] != null)
				return Request.Cookies[key].Value;
		}
		catch { }
		return DefaultValue;
	}

	public int GetCookieInt(string key, int DefaultValue)
	{
		try
		{
			if (Request.Cookies[key] != null)
				return Convert.ToInt32(Request.Cookies[key].Value);
		}
		catch { }
		return DefaultValue;
	}

	//========================================
	public void SetCookie(string key, int NewValue) { SetCookie(key, NewValue.ToString(), 999); }
	public void SetCookie(string key, int NewValue, int ExpireDays) { SetCookie(key, NewValue.ToString(), ExpireDays); }
	public void SetCookie(string key, string NewValue) { SetCookie(key, NewValue, 999); }
	public void SetCookie(string key, string NewValue, int ExpireDays)
	{
		try
		{
			if (Response.Cookies[key] == null)
			{
				HttpCookie cookie = new HttpCookie(key, NewValue);
				cookie.Expires = DateTime.Now.AddDays(ExpireDays);
				Response.Cookies.Add(cookie);
			}
			else
			{
				Response.Cookies[key].Value = NewValue;
				Response.Cookies[key].Expires = DateTime.Now.AddDays(ExpireDays);
			}
		}
		catch { }
	}

	//========================================
	public void RemoveCookie(string key)
	{
		try { Response.Cookies.Remove(key); }
		catch { }
	}

	//========================================
	public void ClearAllCookies()
	{
		try { Response.Cookies.Clear(); }
		catch { }
	}

	//========================================
	private static bool CBoolEx(string s) { return CBoolEx(s, false); }
	private static bool CBoolEx(string s, bool DefaultValue)
	{
		try {
			switch (s.Trim().ToUpper()) {
				case "1":
				case "-1":
				case "T":
				case "TRUE":
				case "OK":
				case "OKAY":
				case "ON":
				case "Y":
				case "YES":
					return true;
				case "0":
				case "F":
				case "FALSE":
				case "OFF":
				case "N":
				case "NO":
					return false;
			}
		} catch { }
		return DefaultValue; 
	}
}