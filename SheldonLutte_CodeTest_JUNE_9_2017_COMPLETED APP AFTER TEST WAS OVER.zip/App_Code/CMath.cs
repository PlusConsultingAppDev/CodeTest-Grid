﻿// Copyright © 2013-2014 One 2 Three, Inc. All rights reserved. Duplication, distribution and adaptation are not permitted.
using System;
using System.Data;

/// <summary>
/// General data conversion routines
/// </summary>
public sealed class CMath
{
	public CMath() { }

	public static bool IsNumeric(string s)
	{
		int d = 0;
		for (int i = 0; i < Math.Min(s.Length, 32); i++){
			if (s[i] == '.') { if (++d > 1) return false; }
			else if (!Char.IsNumber(s[i])) return false;
		}
		return true;

		/*
		if (s.Length == 0) return false;
		try {
			double d = Convert.ToDouble(s);
			return true;
		} catch { }
		return false;
		*/
	}

	public static bool IsDate(string s)
	{
		try {
			DateTime dt = DateTime.Parse(s);
			return true;
		} catch { return false; }
	}

	public static int CInt(string s) { return CInt(s, 0); }
	public static int CInt(string s, int DefaultValue)
	{
		try {
			int i = Convert.ToInt32(s.Trim());
			return i;
		} catch { return DefaultValue; }
	}

	public static double CDouble(string s) { return CDouble(s, 0); }
	public static double CDouble(string s, double DefaultValue)
	{
		try
		{
			double d = Convert.ToDouble(s.Trim());
			return d;
		} catch { return DefaultValue; }
	}

	public static Single CSingle(string s) { return CSingle(s, 0); }
	public static Single CSingle(string s, Single DefaultValue)
	{
		try {
			Single n = Convert.ToSingle(s.Trim(' ', '$'));
			return n;
		} catch { return DefaultValue; }
	}

	public static bool CBoolEx(string s)
	{
		try {
			switch (s.Trim().ToUpper()) {
				case "1":
				case "-1":
				case "T":
				case "TRUE":
				case "OK":
				case "OKAY":
				case "ON":
				case "Y":
				case "YES":
					return true;
				default:
					return false;
			}
		} catch { return false; }
	}

	public static DateTime CDateTime(string s) { return CDateTime(s, DateTime.MinValue); }
	public static DateTime CDateTime(string s, DateTime DefaultValue)
	{
		try {
			DateTime dt = DateTime.Parse(s);
			return dt;
		} catch { return DefaultValue; }
	}
}
