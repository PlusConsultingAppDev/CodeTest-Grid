﻿// Copyright © 2013-2015 One 2 Three, Inc. All rights reserved. Duplication, distribution and adaptation are not permitted.
// Author: Sheldon Lutte - By contract, the intellectual property and technology of this work is solely owned by One 2 Three, Inc. Crate and Barrel has exclusive, non-transferable right to use and modify this code for internal use for an unlimited period of time.

function getCaretRow(ta, inclSel) {
	var cp = (inclSel == 0 ? getCaretPos(ta).start : cp = getCaretPos(ta).end);
	return getRowCount(ta, cp);
}

function getRowCount(ta, cp) {

	if (cp <= 0) return 1;

	//create temp span element to measure text
	var span = document.createElement("SPAN");
	span.style.position = "fixed";
	span.style.left = "-1000px";
	span.style.whiteSpace = "pre-line";
	span.style.fontFamily = ta.currentStyle.fontFamily;
	span.style.fontSize = ta.currentStyle.fontSize;
	span.style.fontStyle = ta.currentStyle.fontStyle;
	span.style.display = "inline-block";
	span.style.width = ta.offsetWidth + "px";
	span.style.height = "auto";

	var txt = ta.value;
	if (cp > txt.length) cp = txt.length;
	while (cp < txt.length) {
		if (txt[cp] == ' ' || txt[cp] == '\n') break; cp++;
	}
	while (cp < txt.length) {
		if (txt[cp] != ' ') break; cp++;
	}

	//must attached to doc to be measureable
	document.body.appendChild(span);

	//measure 1 row
	span.value = "X";
	var h0 = span.offsetHeight;

	//measure specified text
	span.value = txt.substr(0, cp);
	var h = span.offsetHeight;

	document.body.removeChild(span);

	return h / h0;	//return row count
}

function getLineCt(tbox) {
	//use caret function to calc total lines if not already done
	//getCaretRow(tbox, 0);
	//if (taMeasure == null || taMeasure.getAttribute("i") != tbox.id) {
	//	getCaretRowX(tbox);
	//}
	//return taLineCount;
	return getRowCount(tbox, tbox.value.length);
}

//set cursor position in textbox
function setCaretPos(tbox, caretPos) {
	if (tbox) {
		if (tbox.createTextRange) {
			var range = tbox.createTextRange();
			range.move("character", caretPos);
			range.select();
		}
		else if (tbox.selectionStart) {
			tbox.focus();
			tbox.setSelectionRange(caretPos, caretPos);
		}
		else
			tbox.focus();
	}
}

function getCaretPos(el) {
	var selstart = 0, selend = 0, normalizedValue, range, textInputRange, len, endRange;

	if (typeof el.selectionStart == "number" && typeof el.selectionEnd == "number") {
		selstart = el.selectionStart;
		selend = el.selectionEnd;
	} else {
		if (document.selection) {
			range = document.selection.createRange();

			if (range && range.parentElement() == el) {
				len = el.value.length;
				normalizedValue = el.value.replace(/\r\n/g, "\n");

				// Create a working TextRange that lives only in the input
				textInputRange = el.createTextRange();
				textInputRange.moveToBookmark(range.getBookmark());

				// Check if the start and end of the selection are at the very end
				// of the input, since moveStart/moveEnd doesn't return what we want
				// in those cases
				endRange = el.createTextRange();
				endRange.collapse(false);

				if (textInputRange.compareEndPoints("StartToEnd", endRange) > -1) {
					selstart = selend = len;
				} else {
					selstart = -textInputRange.moveStart("character", -len);
					selstart += normalizedValue.slice(0, selstart).split("\n").length - 1;

					if (textInputRange.compareEndPoints("EndToEnd", endRange) > -1) {
						selend = len;
					} else {
						selend = -textInputRange.moveEnd("character", -len);
						selend += normalizedValue.slice(0, selend).split("\n").length - 1;
					}
				}
			}
		}
	}

	return { start:selstart, end:selend, SelLength:(selend - selstart) };

	//useage
	//var el = document.getElementById("your_textarea");
	//var sel = getCaretPos(el);
	//alert(sel.start + ", " + sel.end);
}

function deselect() {
	if (document.selection)
		document.selection.empty();
	else
		window.getSelection().removeAllRanges();
}
