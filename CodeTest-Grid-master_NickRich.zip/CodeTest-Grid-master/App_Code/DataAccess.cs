﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
/// <summary>
/// Summary description for DataAccess
/// </summary>
public class DataAccess
{

    private string connString()
    {
        string str = @"Server=localhost\SQLExpress;Database=AdventureWorks2012;User Id=sa;Password=TrustMe;";

        return str;

    }

    public string testString = "Class Is Working";

    public DataTable read_products()
    {

        DataTable dt = new DataTable();

        //StoredProd exec procProducts_readAll;

        string query = "exec procProducts_readAll;";

        using (SqlConnection connection = new SqlConnection(connString()))
        {

            try
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.SelectCommand = new SqlCommand(
                    query, connection);
                adapter.Fill(dt);
            }
            catch (Exception ex)
            {
                //ADD Logging
            }
        }

        return dt;
    }

}