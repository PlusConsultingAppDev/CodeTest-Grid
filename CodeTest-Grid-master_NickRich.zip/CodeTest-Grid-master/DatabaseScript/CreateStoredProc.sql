USE [AdventureWorks2012]
GO
/****** Object:  StoredProcedure [dbo].[procProducts_readAll]    Script Date: 6/24/2017 7:09:14 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
Create PROCEDURE [dbo].[procProducts_readAll] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
		SELECT [ProductID]
			  ,[Name]
			  ,[ProductNumber]
			  ,[Color]
			  ,[SafetyStockLevel]
			  ,[ReorderPoint]
			  ,[StandardCost]
			  ,[ListPrice]
		  FROM [Production].[Product]
END