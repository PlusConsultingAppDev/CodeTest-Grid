﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ProductGrid : System.Web.UI.Page
{
    DataAccess da = new DataAccess();
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

        }
        DataTable productData = da.read_products();
        Session["productData"] = productData;
        Session["sortDirection"] = "DESC";

        lbl_errorMessage.Text += "<br />Page Loading";

        gv_productData.DataSource = productData;
        gv_productData.DataBind();

        lbl_errorMessage.Text += "<br />" + "Page Load Complete";

    }

    protected void gv_productData_Sorting(object sender, GridViewSortEventArgs e)
    {
        DataTable dt = Session["productData"] as DataTable;

        if (dt != null)
        {
           
            //Sort the data.
            string sortDirection = "ASC";

            if (Session["sortDirection"] == sortDirection)
                sortDirection = "DESC";

            
            dt.DefaultView.Sort = e.SortExpression + " " + sortDirection;
            gv_productData.DataSource = dt.DefaultView.ToTable();
            gv_productData.DataBind();
        }



    }

    protected void gv_productData_Sorted(object sender, EventArgs e)
    {

    }

    

}