﻿// Copyright © 2013-2015 One 2 Three, Inc. All rights reserved. Duplication, distribution and adaptation are not permitted.
// Author: Sheldon Lutte - By contract, the intellectual property and technology of this work is solely owned by One 2 Three, Inc. Crate and Barrel has exclusive, non-transferable right to use and modify this code for internal use for an unlimited period of time.
using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.IO;
using System.Configuration;
using System.Text;

/// <summary>
/// Encapsulation of database access routines with data conversion and error handling
/// Currently only supports SQL Server
/// </summary>
public class sqlDb : IDisposable
{
	public SqlConnection dbSql = null;

	private string CurConnectString = "";

	//private int QueryCt = 0;
	//private sqlQuery[] Queries;

	public string LastSource = "";
	public string LastMessage = "";

	//===================================
	//Constructor
	public sqlDb() { }
	public sqlDb(string ConnectionString) { Open(ConnectionString); }

	#region IDisposable implementation
	public void Dispose() {
		Dispose(true);
		GC.SuppressFinalize(this);
	}

	private bool m_Disposed = false;
	protected virtual void Dispose(bool disposing) {
		if (!m_Disposed) {
			if (disposing) {
				dbSql.Dispose();
			}

			// Unmanaged resources are released here.

			m_Disposed = true;
		}
	}

	~sqlDb() {
		Dispose(false);
	}
	#endregion

	//===================================
	//Open or close database
	public bool Open() { return Open(CurConnectString); }
	public bool Open(string ConnectionString)
	{
		try {
			Close();		//ensure previous connection is closed

			CurConnectString = ConnectionString.Trim();

			//if (CurConnectString.Length == 0)
			//	CurConnectString = WebDBConnectionString();

			if (CurConnectString.Length == 0)
				return false;
	
			if (!CurConnectString.EndsWith(";"))
				CurConnectString += ";";

			//fix the connection string to allow multiple queries using same SQL statement
			//(this fixes a change in SQL 2005)
			if (CurConnectString.IndexOf("MultipleActiveResultSets=True", StringComparison.OrdinalIgnoreCase) == -1)
				CurConnectString += "MultipleActiveResultSets=True";

			dbSql = new SqlConnection(CurConnectString);

			if (dbSql != null)
			{
				dbSql.Open();

				if (dbSql.State == ConnectionState.Broken)
				{
					LastSource = "sqlDb.Open";
					LastMessage = "Connection broken";
				}
				else if (dbSql.State == ConnectionState.Closed)
				{
					LastSource = "sqlDb.Open";
					LastMessage = "Connection closed";
				}
				else
					return true;
			}
		}
		catch (Exception ex)
		{
			LastSource = ex.Source;
			LastMessage = "Connection failed. " + ex.Message + (ex.InnerException != null ? ex.InnerException.Message : "");
		}
		return false;
	}
	public bool Close()
	{
		try {
			if (dbSql != null) dbSql.Close();
			return true;
		}
		catch (Exception ex)
		{
			LastSource = ex.Source;
			LastMessage = ex.Message + (ex.InnerException != null ? ex.InnerException.Message : "");
			return false;
		}
	}
	public bool Reconnect()
	{
		Close();
		return Open();
	}

	public bool IsOpen { get { return (dbSql != null && dbSql.State == ConnectionState.Open); } }

	//===================================
	//open and return a new query on the current database
	public sqlQuery OpenQuery(string sql)
	{
		try
		{
			//open database if possible
			if (!IsOpen) if (!Open()) return null;

			//open the sql query
			sqlQuery q = new sqlQuery();
			if (!q.Open(this, sql)) {
				LastSource = q.LastError;
				LastMessage = q.LastMessage;
				q = null;
			}

			//return the query management object
			return q;
		}
		catch (Exception ex)
		{
			LastSource = ex.Source;
			LastMessage = "Query failed. " + ex.Message + (ex.InnerException != null ? ex.InnerException.Message : "");
		}
		return null;
	}

	//===================================
	//--------------------------------------------------
	// Exec
	// execute a non-SELECT SQL Statement
	// return number of rows affected or <0 if error
	//--------------------------------------------------
	public int Exec(string sql)
	{
		int RowCount = -1;
		try {
			if (dbSql == null) return -1;
			SqlCommand dbcmd = new SqlCommand(sql, dbSql);
			RowCount = dbcmd.ExecuteNonQuery();
		} catch (Exception ex) {
			if (RowCount >= 0) RowCount = -1;
			LastSource = ex.Source;
			LastMessage = "Query failed. " + ex.Message + (ex.InnerException != null ? ex.InnerException.Message : "");
		}
		return RowCount;
	}

	//===================================
	//--------------------------------------------------
	// ReadFirstObject
	//--------------------------------------------------
	private object ReadFirstObject(string sql)
	{
		try {
			SqlCommand dbcmd = new SqlCommand(sql, dbSql);
			return dbcmd.ExecuteScalar();
		}
		catch (Exception ex) {
			LastSource = ex.Source;
			LastMessage = ex.Message + (ex.InnerException != null ? ex.InnerException.Message : "");
		}
		return null;
	}

	//--------------------------------------------------
	// ReadFirstInt
	//--------------------------------------------------
	public int ReadFirstInt(string sql) { return ReadFirstInt(sql, 0); }
	public int ReadFirstInt(string sql, int DefaultValue)
	{
		try {
			object obj = ReadFirstObject(sql);
			if (obj != null) return Convert.ToInt32(obj);
		} catch { }
		return DefaultValue;
	}

	//--------------------------------------------------
	// ReadFirstSingle
	//--------------------------------------------------
	public Single ReadFirstSingle(string sql) { return ReadFirstSingle(sql, (Single)0); }
	public Single ReadFirstSingle(string sql, Single DefaultValue)
	{
		try {
			object obj = ReadFirstObject(sql);
			if (obj != null) return Convert.ToSingle(obj);
		} catch { }
		return DefaultValue;
	}

	//--------------------------------------------------
	// ReadFirstInt
	//--------------------------------------------------
	public double ReadFirstDouble(string sql) { return ReadFirstDouble(sql, (double)0); }
	public double ReadFirstDouble(string sql, double DefaultValue)
	{
		try {
			object obj = ReadFirstObject(sql);
			if (obj != null) return Convert.ToDouble(obj);
		} catch { }
		return DefaultValue;
	}

	//--------------------------------------------------
	// ReadFirstBool
	//--------------------------------------------------
	public bool ReadFirstBool(string sql) { return ReadFirstBool(sql, false); }
	public bool ReadFirstBool(string sql, bool DefaultValue)
	{
		try {
			object obj = ReadFirstObject(sql);
			if (obj == null) return DefaultValue;		//data missing, return default

			switch (Convert.ToString(obj).Trim().ToUpper()) {
				case "TRUE":
				case "T":
				case "YES":
				case "Y":
				case "OK":
				case "ON":
				case "OUI":	//french
				case "1":
				case "-1":
					return true;

				case "":
				case "NULL":
					return DefaultValue;		//data missing, return default
		
				default:
					return false;
			}
		} catch { }

		return DefaultValue;		//on error, return default value
	}

	//--------------------------------------------------
	// ReadFirstChar
	//--------------------------------------------------
	public char ReadFirstChar(string sql) { return ReadFirstChar(sql, '\0'); }
	public char ReadFirstChar(string sql, char DefaultValue)
	{
		try {
			object obj = ReadFirstObject(sql);
			if (obj != null) return Convert.ToChar(obj);
		} catch { }
		return DefaultValue;
	}

	//--------------------------------------------------
	// ReadFirstString
	//--------------------------------------------------
	public string ReadFirstString(string sql) { return ReadFirstString(sql, ""); }
	public string ReadFirstString(string sql, string DefaultValue)
	{
		try {
			object obj = ReadFirstObject(sql);
			if (obj != null) return Convert.ToString(obj);
		} catch { }
		return DefaultValue;
	}

	//--------------------------------------------------
	// ReadFirstDateTime
	//--------------------------------------------------
	public DateTime ReadFirstDateTime(string sql) { return ReadFirstDateTime(sql, DateTime.MinValue); }
	public DateTime ReadFirstDateTime(string sql, DateTime DefaultValue)
	{
		try {
			object obj = ReadFirstObject(sql);
			if (obj != null) return Convert.ToDateTime(obj);
		} catch { }
		return DefaultValue;
	}


	#region SQL Keyword Translation for Specified DB Type
	//==================================================
	// SQL Keyword Translation
	// Format for sql syntax based on type of DB connection
	//==================================================
	public string NOW { get { return ("GetDate()"); } }
	public string NULL { get { return ("NULL"); } }
	public string UCASE(string parm) { return ("UPPER(" + parm + ")"); }

	public string TRUE { get { return ("1"); } }
	public string FALSE { get { return ("0"); } }
	public string BOOL(bool parm)	{ return (parm ? "1" : "0"); }

	public string OR { get { return (" | "); } }

	public string TEXT(char data)	{
		//WARNING! THIS WILL NOT HANDLE OUT-OF-RANGE CHARS ASCII 0 to 32, 256+
		if (data == '\'') return "''''"; else return ("'" + data.ToString() + "'");
	}

	public string TEXT(string data) {
		//WARNING! THIS WILL NOT HANDLE OUT-OF-RANGE CHARS ASCII 0 to 32, 256+
		return ("'" + data.Trim().Replace("'", "''") + "'");
	}

	public string TEXT(string data, bool nullWhenBlank, bool trim, int maxlen, bool Unicode)
	{
		//note: carriage returns must be represented in SQL as CHAR(13) + CHAR(10)
		if (trim) data = data.Trim();
		if (data.Length == 0) return this.NULL;
		if (maxlen > 0 && data.Length > maxlen) data = data.Substring(0, maxlen);

		data = data.Replace("'", "''");

		//replace non-printable chars with sql-safe functions
		for (int c = 0; c < 32; c++)
			data.Replace(((char)c).ToString(), "' + CHAR(" + c.ToString() + ") + '");

		return ((Unicode ? "N'" : "'") + data + "'");
	}

	public string FIRST(string parm) { return ("TOP 1 " + parm); }
	public string TRIM(string parm) { return ("LTRIM(RTRIM(" + parm + "))"); }

	public string CASE(string condition, string parmthen, string parmelse){
		return CASE(condition, parmthen, parmelse, "");
	}
	public string CASE(string condition, string parmthen, string parmelse, string fldname)
	{
		return "CASE WHEN (" + condition + ") THEN (" + parmthen + ") ELSE (" + parmelse + ") END"
			+ (fldname.Length > 0 ? " [" + fldname + "]" : "");
	}

	//convert any number or date to a string in the query return data
	public string STRINGVALUE(string parm) { return ("CONVERT(varchar," + parm + ")"); }

	//remove time portion from datetime
	public string DATEVALUE(string fld){ return "CAST(FLOOR(CAST(" + fld + " AS FLOAT))AS DATETIME)";	}

	public string DATEDIFF_DAYS(string parm1, string parm2){ return "DATEDIFF(day," + parm1 + "," + parm2 + ")"; }
	public string DATEDIFF_HOURS(string parm1, string parm2){ return "DATEDIFF(hour," + parm1 + "," + parm2 + ")"; }
	public string DATEDIFF_MINUTES(string parm1, string parm2){ return "DATEDIFF(minute," + parm1 + "," + parm2 + ")"; }

	public string DATE(DateTime dt){ return DATE(dt, true); }
	public string DATE(DateTime dt, bool NullWhenMinValue)
	{
		if (dt == DateTime.MinValue && NullWhenMinValue)
			return this.NULL;
		else
			return "'" + dt.ToString("M/d/yyyy") + "' ";
	}

	public string DATERANGE(DateTime dtStart, DateTime dtEnd)
	{
		return "'" + dtStart.ToString("M/d/yyyy") + "' AND '" + dtEnd.ToString("M/d/yyyy") + " 23:59:59'";
	}

	public string DATETIME(DateTime dt) { return DATETIME(dt, true); }
	public string DATETIME(DateTime dt, bool NullWhenMinValue)
	{
		if (dt == DateTime.MinValue && NullWhenMinValue)
			return NULL;
		else
			return "'" + dt.ToString("M/d/yyyy HH:mm:ss") + "' ";
	}

	public string WEEKDAY(DateTime dt) { return "DATEPART(weekday,'" + dt.ToString("M/d/yyyy") + "')"; }
	public string WEEKDAY(string param)	{ return "DATEPART(weekday," + param + ")"; }

	public string SQLData(string val, string fld, bool AllowNulls) 
	{
		if (val.Length == 0 && AllowNulls == true)
			return fld + "=NULL";
		else
			return fld + "='" + val.Replace("'", "''") + "'"; 
	}
	public string SQLData(Boolean val) { return BOOL(val); }
	public string SQLData(Boolean val, string fld) { return fld + "=" + BOOL(val); }
	public string SQLData(int val) { return val.ToString(); }
	public string SQLData(int val, string fld) { return fld + "=" + val.ToString(); }
	public string SQLData(Single val) { return val.ToString(); }
	public string SQLData(Single val, string fld) { return fld + "=" + val.ToString(); }
	public string SQLData(double val) { return val.ToString(); }
	public string SQLData(double val, string fld) { return fld + "=" + val.ToString(); }
	public string SQLData(DateTime val) { return DATETIME(val); }
	public string SQLData(DateTime val, string fld) { return fld + "=" + DATETIME(val); }
	public string SQLData(string val) { return "'" + val.Replace("'", "''") + "'"; }
	public string SQLData(string val, bool AllowNulls) { if (val.Length == 0) return "NULL"; else return "'" + val.Replace("'", "''") + "'"; }
	public string SQLData(string val, string fld) { return fld + "='" + val.Replace("'", "''") + "'"; }

	#endregion

	#region Record Field Get Value Handle Nulls
	//========================================
	public string GetFieldString(ref System.Data.Common.DbDataRecord rec, string fieldname)
	{
		return GetFieldString(ref rec, fieldname, "");
	}
	public string GetFieldString(ref System.Data.Common.DbDataRecord rec, string fieldname, string DefaultValue)
	{
		try
		{
			if (rec != null)
			{
				int i = rec.GetOrdinal(fieldname);
				if (i >= 0 && i < rec.FieldCount && rec.IsDBNull(i) == false)
					return rec.GetString(i);
			}
		}
		catch { }
		return DefaultValue;
	}
	public string GetFieldString(ref System.Data.Common.DbDataRecord rec, int fld, string DefaultValue)
	{
		try
		{
			if (rec != null && fld >= 0 && fld < rec.FieldCount && rec.IsDBNull(fld) == false)
				return rec.GetString(fld);
		}
		catch { }
		return DefaultValue;
	}
	//========================================
	public int GetFieldInt(ref System.Data.Common.DbDataRecord rec, string fieldname)
	{
		return GetFieldInt(ref rec, fieldname, 0);
	}
	public int GetFieldInt(ref System.Data.Common.DbDataRecord rec, string fieldname, int DefaultValue)
	{
		try
		{
			if (rec != null)
			{
				int i = rec.GetOrdinal(fieldname);
				if (i >= 0 && i < rec.FieldCount && rec.IsDBNull(i) == false)
					return Convert.ToInt32(rec[fieldname]);
			}
		}
		catch { }
		return DefaultValue;
	}
	public int GetFieldInt(ref System.Data.Common.DbDataRecord rec, int fld, int DefaultValue)
	{
		try
		{
			if (rec != null && fld >= 0 && fld < rec.FieldCount && rec.IsDBNull(fld) == false)
				return Convert.ToInt32(rec[fld]);
		}
		catch { }
		return DefaultValue;
	}
	//========================================
	public Single GetFieldSingle(ref System.Data.Common.DbDataRecord rec, string fieldname)
	{
		return GetFieldSingle(ref rec, fieldname, 0);
	}
	public Single GetFieldSingle(ref System.Data.Common.DbDataRecord rec, string fieldname, Single DefaultValue)
	{
		try
		{
			if (rec != null)
			{
				int i = rec.GetOrdinal(fieldname);
				if (i >= 0 && i < rec.FieldCount && rec.IsDBNull(i) == false)
					return Convert.ToSingle(rec[fieldname]);
			}
		}
		catch { }
		return DefaultValue;
	}
	public Single GetFieldSingle(ref System.Data.Common.DbDataRecord rec, int fld, Single DefaultValue)
	{
		try
		{
			if (rec != null && fld >= 0 && fld < rec.FieldCount && rec.IsDBNull(fld) == false)
				return Convert.ToSingle(rec[fld]);
		}
		catch { }
		return DefaultValue;
	}
	//========================================
	public DateTime GetFieldDateTime(ref System.Data.Common.DbDataRecord rec, string fieldname)
	{
		return GetFieldDateTime(ref rec, fieldname, DateTime.MinValue);
	}
	public DateTime GetFieldDateTime(ref System.Data.Common.DbDataRecord rec, string fieldname, DateTime DefaultValue)
	{
		try
		{
			if (rec != null)
			{
				int i = rec.GetOrdinal(fieldname);
				if (i >= 0 && i < rec.FieldCount && rec.IsDBNull(i) == false)
					return rec.GetDateTime(i);
			}
		}
		catch { }
		return DefaultValue;
	}
	public DateTime GetFieldDateTime(ref System.Data.Common.DbDataRecord rec, int fld, DateTime DefaultValue)
	{
		try
		{
			if (rec != null && fld >= 0 && fld < rec.FieldCount && rec.IsDBNull(fld) == false)
				return rec.GetDateTime(fld);
		}
		catch { }
		return DefaultValue;
	}
	//========================================
	public bool GetFieldBool(ref System.Data.Common.DbDataRecord rec, string fieldname)
	{
		return GetFieldBool(ref rec, fieldname, false);
	}
	public bool GetFieldBool(ref System.Data.Common.DbDataRecord rec, string fieldname, bool DefaultValue)
	{
		try
		{
			if (rec != null)
			{
				int i = rec.GetOrdinal(fieldname);
				if (i >= 0 && i < rec.FieldCount && rec.IsDBNull(i) == false)
					return CMath.CBoolEx(rec.GetValue(i).ToString());
			}
		}
		catch { }
		return DefaultValue;
	}
	public bool GetFieldBool(ref System.Data.Common.DbDataRecord rec, int fld, bool DefaultValue)
	{
		try
		{
			if (rec != null && fld >= 0 && fld < rec.FieldCount && rec.IsDBNull(fld) == false)
				return rec.GetBoolean(fld);
		}
		catch { }
		return DefaultValue;
	}

	//========================================
	public char GetFieldChar(ref System.Data.Common.DbDataRecord rec, string fieldname, char DefaultValue)
	{
		try
		{
			if (rec != null)
			{
				int i = rec.GetOrdinal(fieldname);
				if (i >= 0 && i < rec.FieldCount && rec.IsDBNull(i) == false)
					return rec.GetChar(i);
			}
		}
		catch { }
		return DefaultValue;
	}
	public char GetFieldChar(ref System.Data.Common.DbDataRecord rec, int fld, char DefaultValue)
	{
		try
		{
			if (rec != null && fld >= 0 && fld < rec.FieldCount && rec.IsDBNull(fld) == false)
				return rec.GetChar(fld);
		}
		catch { }
		return DefaultValue;
	}
	#endregion

	//========================================
	public string WebDBConnectionString(string dbname) {
		try { return (System.Configuration.ConfigurationManager.ConnectionStrings[dbname].ConnectionString);
		} catch { return ""; }
	}

	//========================================
	public bool BindRepeater(ref System.Web.UI.WebControls.Repeater r, string sql)
	{
		try
		{
			SqlCommand dbcmd = new SqlCommand(sql, dbSql);
			SqlDataReader dbread = dbcmd.ExecuteReader();
			r.DataSource = dbread;
			r.DataBind();
			dbread.Close();
		}
		catch { return false; }
		return true;
	}

	//========================================
	//parse quoted phrases from string
	public string GetSqlWordListString(string[] wordlist)
	{
		string result = "";
		foreach (string word in wordlist)
		{
			result += ", " + TEXT(word);
		}
		if (result.Length > 0) return result.Substring(2); else return "";
	}

	//========================================
	public string GetSqlWordListString(string words, string delim)
	{
		return GetSqlWordListString(GetSqlWordList(words, delim, true));
	}

	//parse quoted phrases from string
	public string[] GetSqlWordList(string words, string ParseDelim, bool AsText)
	{
		//if source string only contains delimiters, return empty array
		words = words.Trim(ParseDelim.ToCharArray());
		if (words.Length == 0) return new string[] { };

		List<string> result = new List<string>();
		int LastChar = words.Length - 1;
		char[] delims = (ParseDelim + "\"").ToCharArray();
		int n1 = 0, n2 = -1;
		while(n2 < LastChar)
		{
			//find next delim
			n1 = n2 + 1;
			n2 = words.IndexOfAny(delims, n1);
			//if no delim found, add remainder of string to array
			if (n2 == -1){
				if (AsText)
					result.Add(TEXT(words.Substring(n1)));		//fix string for use in SQL, append to comma delimited list of string values
				else
					result.Add(words.Substring(n1));		//fix string for use in SQL, append to comma delimited list of string values
				break;
			}

			//find next quote char
			if (words[n2] == '\"')
			{
				// ignore double quotes following numbers (ex. 9"), assume it's an inch mark
				if (n2 > 0 && "0123456789".IndexOf(words[n2 - 1]) > -1) break;
				//find closing quote
				n1 = n2 + 1;
				while (true)
				{
					n2 = words.IndexOf('\"', n2 + 1);
					if (n2 == -1 || n2 >= LastChar) { n2 = LastChar; break; }
					if (words[n2 + 1] == '\"') n2++; else break;
				}
				//convert "" to ", remove bounding quotes, fix string for SQL and add to word list (ex. "the ""big"" 3' bird" becomes |the "big" 3'' bird|)
				if (AsText)
					result.Add(TEXT(words.Substring(n1, n2 - n1).Replace("\"\"", "\"")));
				else
					result.Add(words.Substring(n1, n2 - n1).Replace("\"\"", "\""));
				//break;
			}
			else if (n2 > n1)
			{
				//ignore dot as delimiter if part of a number
				//if (words[n2] == '.' 
				//	&& ("0123456789".IndexOf(words[n2 - 1]) > -1 
				//		|| (n2 < LastChar && "0123456789".IndexOf(words[n2 + 1]) > -1))) 
				//	//break;

				if (AsText)
					result.Add(TEXT(words.Substring(n1, n2 - n1).Trim()));
				else
					result.Add(words.Substring(n1, n2 - n1).Trim());
				//break;
			}
		}

		return result.ToArray();
	}

	//========================================
	public string GetSqlWordListFilter(string SearchSpec, string[] FieldList)
	{
		return GetSqlWordListFilter(GetSqlWordList(SearchSpec, " ,+;", false), FieldList, null, false);
	}
	public string GetSqlWordListFilter(string[] wordlist, string[] FieldList, string[] NumericFieldList, bool ExactMatch)
	{
		bool WordIsNumeric = false;
		StringBuilder sqlFieldMatches = new StringBuilder();
		StringBuilder sql = new StringBuilder();
		string WordText;

		if (ExactMatch)
		{
			string DelimitedValueList = GetSqlWordListString(wordlist);
			foreach (string fld in FieldList)
			{
				if (fld.Length > 0)
					sqlFieldMatches.Append(" OR ").Append(fld).Append(" IN (").Append(DelimitedValueList).Append(")");
			}
			if (sqlFieldMatches.Length > 4)
				sql.Append(" AND (").Append(sqlFieldMatches.Remove(0, 4)).Append(")");

			sqlFieldMatches.Clear();
		}
		else
		{
			foreach (string word in wordlist)
			{
				if (word.Length > 0)
				{
					WordIsNumeric = CMath.IsNumeric(word);
					if (word[0] == '\'')
						WordText = word.Substring(1, word.Length - 2);
					else
						WordText = word.Replace("'", "''");

					//match to varchar fields
					foreach (string fld in FieldList)
					{
						if (fld.Length > 0)
						{
							WordText = WordText.Replace("%", "[%]");
							sqlFieldMatches.Append(" OR ' ' + ").Append(fld).Append(" + ' ' LIKE N'%[^a-z]").Append(WordText).Append("[^a-z]%'");

							//get other word forms (singular, plural, abrev.)
							//wordAlt = db.ReadFirstString("SELECT Singular FROM Dictionary WHERE Plural = '" + word + "'");
							//if (wordAlt.Length > 0) sqlFieldMatches += " OR [" + fld + "] LIKE '%[^a-z]" + wordAlt + "[^a-z]%')";

							//wordAlt = db.ReadFirstString("SELECT Plural FROM Dictionary WHERE Singular = '" + word + "'");
							//if (wordAlt.Length > 0) sqlFieldMatches += " OR [" + fld + "] LIKE '%[^a-z]" + wordAlt + "[^a-z]%')";
						}
					}

					//match to numeric fields
					if (WordIsNumeric && NumericFieldList != null)
					{
						foreach (string fld in NumericFieldList)
						{
							if (fld.Length > 0)
								sqlFieldMatches.Append(" OR ").Append(fld).Append("=").Append(WordText);
						}
					}

					//build the list
					if (sqlFieldMatches.Length > 4)
						sql.Append(" AND (").Append(sqlFieldMatches.Remove(0, 4)).Append(")");

					sqlFieldMatches.Clear();
				}
			}
		}

		//remove leading "AND" from string
		if (sql.Length > 5)
			sql.Remove(0, 5).Insert(0, '(').Append(')');

		return sql.ToString();
	}

	//========================================
	public DataSet GetDataSet(string sql)
	{
		try
		{
			SqlCommand dbcmd = new SqlCommand(sql, dbSql);
			SqlDataAdapter dba = new SqlDataAdapter(dbcmd);
			DataSet ds = new DataSet();
			dba.Fill(ds);
			return ds;
		}
		catch { return null; }
	}
}
