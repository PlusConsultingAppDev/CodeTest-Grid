// Copyright � 2013-2015 One 2 Three, Inc. All rights reserved. Duplication, distribution and adaptation are not permitted.
// Author: Sheldon Lutte - By contract, the intellectual property and technology of this work is solely owned by One 2 Three, Inc. Crate and Barrel has exclusive, non-transferable right to use and modify this code for internal use for an unlimited period of time.
using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Procedures, wrappers and shortcuts for data retrieval and convertion from Database Records
/// This is solely used in "Item Data Bound" routines for asp repeaters
/// </summary>
public class sqlDataset
{
	private System.Data.Common.DbDataRecord CurrentRecord = null;

	public string DefaultString = "";
	public char DefaultChar = ' ';
	public int DefaultInt = 0;
	public double DefaultDouble = 0;
	public bool DefaultBool = false;
	public DateTime DefaultDateTime = DateTime.MinValue;

	//========================================
	public sqlDataset() { }
	public sqlDataset(System.Data.Common.DbDataRecord Record) { CurrentRecord = Record; }

	//========================================
	public string GetString(string fieldname) { return GetString(fieldname, DefaultString, ""); }
	public string GetString(string fieldname, string DefaultValue) { return GetString(fieldname, DefaultValue, ""); }
	public string GetString(string fieldname, string DefaultValue, string FormatMask)
	{
		try
		{
			if (CurrentRecord != null)
			{
				int i = CurrentRecord.GetOrdinal(fieldname);
				if (i < 0 || i >= CurrentRecord.FieldCount) return DefaultValue;
				if (CurrentRecord.IsDBNull(i)) return DefaultValue;

				Type FieldType = CurrentRecord.GetFieldType(i);

				if (FieldType == typeof(string)) return CurrentRecord.GetString(i);

				if (FieldType == typeof(bool))
					if (CurrentRecord.GetBoolean(i)) return "True"; else return "False";

				if (FieldType == typeof(int))	return CurrentRecord.GetInt16(i).ToString(FormatMask);
				if (FieldType == typeof(long)) return CurrentRecord.GetInt32(i).ToString(FormatMask);
				return DefaultValue;
			}
		}
		catch (Exception) { }
		return DefaultValue;
	}
	public string GetString(int fld) { return GetString(fld, DefaultString); }
	public string GetString(int fld, string DefaultValue)
	{
		try
		{
			if (CurrentRecord != null && fld >= 0 && fld < CurrentRecord.FieldCount && CurrentRecord.IsDBNull(fld) == false)
				return CurrentRecord.GetString(fld);
		}
		catch (Exception) { }
		return DefaultValue;
	}
	//========================================
	public int GetInt(string fieldname) { return GetInt(fieldname, DefaultInt); }
	public int GetInt(string fieldname, int DefaultValue)
	{
		try
		{
			if (CurrentRecord != null)
			{
				int i = CurrentRecord.GetOrdinal(fieldname);
				if (i >= 0 && i < CurrentRecord.FieldCount && CurrentRecord.IsDBNull(i) == false)
					return Convert.ToInt32(CurrentRecord[fieldname]);
			}
		}
		catch (Exception) { }
		return DefaultValue;
	}
	public int GetInt(int fld) { return GetInt(fld, DefaultInt); }
	public int GetInt(int fld, int DefaultValue)
	{
		try
		{
			if (CurrentRecord != null && fld >= 0 && fld < CurrentRecord.FieldCount && CurrentRecord.IsDBNull(fld) == false)
				return Convert.ToInt32(CurrentRecord[fld]);
		}
		catch (Exception) { }
		return DefaultValue;
	}
	//========================================
	public double GetDouble(string fieldname) { return GetDouble(fieldname, DefaultDouble); }
	public double GetDouble(string fieldname, double DefaultValue)
	{
		try
		{
			if (CurrentRecord != null)
			{
				int i = CurrentRecord.GetOrdinal(fieldname);
				if (i >= 0 && i < CurrentRecord.FieldCount && CurrentRecord.IsDBNull(i) == false)
					return Convert.ToDouble(CurrentRecord[fieldname]);
			}
		}
		catch (Exception) { }
		return DefaultValue;
	}
	public double GetDouble(int fld) { return GetDouble(fld, DefaultDouble); }
	public double GetDouble(int fld, double DefaultValue)
	{
		try
		{
			if (CurrentRecord != null && fld >= 0 && fld < CurrentRecord.FieldCount && CurrentRecord.IsDBNull(fld) == false)
				return Convert.ToDouble(CurrentRecord[fld]);
		}
		catch (Exception) { }
		return DefaultValue;
	}
	//========================================
	public DateTime GetDateTime(string fieldname) { return GetDateTime(fieldname, DefaultDateTime); }
	public DateTime GetDateTime(string fieldname, DateTime DefaultValue)
	{
		try
		{
			if (CurrentRecord != null)
			{
				int i = CurrentRecord.GetOrdinal(fieldname);
				if (i >= 0 && i < CurrentRecord.FieldCount && CurrentRecord.IsDBNull(i) == false)
					return CurrentRecord.GetDateTime(i);
			}
		}
		catch (Exception) { }
		return DefaultValue;
	}
	public DateTime GetDateTime(int fld) { return GetDateTime(fld, DefaultDateTime); }
	public DateTime GetDateTime(int fld, DateTime DefaultValue)
	{
		try
		{
			if (CurrentRecord != null && fld >= 0 && fld < CurrentRecord.FieldCount && CurrentRecord.IsDBNull(fld) == false)
				return CurrentRecord.GetDateTime(fld);
		}
		catch (Exception) { }
		return DefaultValue;
	}
	//========================================
	public bool GetBool(string fieldname) { return GetBool(fieldname, DefaultBool); }
	public bool GetBool(string fieldname, bool DefaultValue)
	{
		try
		{
			if (CurrentRecord != null)
			{
				int i = CurrentRecord.GetOrdinal(fieldname);

				if (i < 0 || i > CurrentRecord.FieldCount) return DefaultValue;
				if (CurrentRecord.IsDBNull(i)) return DefaultValue;

				Type FieldType = CurrentRecord.GetFieldType(i);
				if (FieldType == typeof(bool)) return CurrentRecord.GetBoolean(i);

				if (FieldType == typeof(string))
					switch (((string)CurrentRecord.GetString(i)).Trim().ToUpper())
					{
						case "TRUE":
						case "T":
						case "YES":
						case "Y":
						case "1":
						case "-1":
						case "OK":
						case "ON":
							return true;
						default:
							return false;
					}

				if (FieldType == typeof(char))
					switch (CurrentRecord.GetChar(i)){
						case 'Y':
						case 'y':
						case 'T':
						case 't':
						case '1':
							return true;
						default:
							return false;
					}

				if (FieldType == typeof(byte)) return ((byte)CurrentRecord.GetByte(i) != 0);
				if (FieldType == typeof(short)) return ((short)CurrentRecord.GetInt16(i) != 0);
				if (FieldType == typeof(int)) return ((int)CurrentRecord.GetInt32(i) != 0);
				if (FieldType == typeof(Int16)) return ((Int16)CurrentRecord.GetInt16(i) != 0);
				if (FieldType == typeof(Int32)) return ((Int32)CurrentRecord.GetInt32(i) != 0);
				if (FieldType == typeof(Int64)) return ((Int64)CurrentRecord.GetInt64(i) != 0);
				if (FieldType == typeof(long)) return ((long)CurrentRecord.GetInt64(i) != 0);
				if (FieldType == typeof(Single)) return ((Single)CurrentRecord.GetFloat(i) != 0);
				if (FieldType == typeof(double)) return ((double)CurrentRecord.GetDouble(i) != 0);
				//if (FieldType == typeof(ushort)) return ((ushort)CurrentRecord.GetInt16(i) != 0);
				//if (FieldType == typeof(uint)) return ((uint)CurrentRecord.GetInt32(i) != 0);
				//if (FieldType == typeof(UInt16)) return ((UInt16)CurrentRecord.GetInt16(i) != 0);
				//if (FieldType == typeof(UInt32)) return ((UInt32)CurrentRecord.GetInt32(i) != 0);
				//if (FieldType == typeof(UInt64)) return ((UInt64)CurrentRecord.GetInt64(i) != 0);
			}
		}
		catch (Exception) { }
		return DefaultValue;
	}
	public bool GetBool(int fld) { return GetBool(fld, DefaultBool); }
	public bool GetBool(int fld, bool DefaultValue)
	{
		try
		{
			if (CurrentRecord != null && fld >= 0 && fld < CurrentRecord.FieldCount && CurrentRecord.IsDBNull(fld) == false)
				return CurrentRecord.GetBoolean(fld);
		}
		catch (Exception) { }
		return DefaultValue;
	}

	//========================================
	public char GetChar(string fieldname) { return GetChar(fieldname, DefaultChar); }
	public char GetChar(string fieldname, char DefaultValue)
	{
		try
		{
			if (CurrentRecord != null)
			{
				int i = CurrentRecord.GetOrdinal(fieldname);
				if (i >= 0 && i < CurrentRecord.FieldCount && CurrentRecord.IsDBNull(i) == false)
					return CurrentRecord.GetChar(i);
			}
		}
		catch (Exception) { }
		return DefaultValue;
	}
	public char GetChar(int fld) { return GetChar(fld, DefaultChar); }
	public char GetChar(int fld, char DefaultValue)
	{
		try
		{
			if (CurrentRecord != null && fld >= 0 && fld < CurrentRecord.FieldCount && CurrentRecord.IsDBNull(fld) == false)
				return CurrentRecord.GetChar(fld);
		}
		catch (Exception) { }
		return DefaultValue;
	}
}
