﻿// Copyright © 2013-2015 One 2 Three, Inc. All rights reserved. Duplication, distribution and adaptation are not permitted.
// Author: Sheldon Lutte - By contract, the intellectual property and technology of this work is solely owned by One 2 Three, Inc. Crate and Barrel has exclusive, non-transferable right to use and modify this code for internal use for an unlimited period of time.
using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Encapsulation of database query access routines with data conversion and error handling
/// Currently only supports SQL Server
/// </summary>
public class sqlQuery
{
	SqlCommand dbcmdSql = null;
	SqlDataReader dbreadSql = null;

	private string curSql = "";
	private int ReadCt = 0;
	private bool eof = false;

	public string LastError = "";
	public string LastMessage = "";

	//===================================
	//constructor
	public sqlQuery() { }
	public sqlQuery(sqlDb db, string sql) { Open(db, sql); }

	//===================================
	#region Open/Read/Close
	//close the query, dump the cache
	public bool Open(sqlDb db, string sql)
	{
		try {
			Close();
			curSql = sql.Trim();
			if (curSql.Length > 0 && db != null) {
				if (!db.IsOpen) if (!db.Open()) return false;
				dbcmdSql = new SqlCommand(curSql, db.dbSql);
				if (dbcmdSql != null) dbreadSql = dbcmdSql.ExecuteReader();
				return true;
			}
		} catch (Exception ex) {
			LastError = ex.Source;
			LastMessage = ex.Message;
		}
		return false;
 	}

	//===================================
	//get next record in current query
	public bool Read()
	{
		try {
			if (dbreadSql.Read()) {
				ReadCt++;
				return true;
			}
		} catch { }
		eof = true;
		return false;
	}

	//===================================
	public void Close()
	{
		try {
			ReadCt = 0;
			eof = false;
			if (!dbreadSql.IsClosed) dbreadSql.Close();
			dbcmdSql = null;
	  } catch { }
	}
	#endregion

	//===================================
	#region Status
	// STATUS
	public bool IsOpen { get { return (dbreadSql != null && dbreadSql.IsClosed == false); } }

	public string SqlText { get { return curSql; } }

	public bool IsUpdatable(int fldindex)
	{
		try
		{
			if (dbreadSql == null) return false;
			if ((bool)(dbreadSql.GetSchemaTable().Rows[fldindex]["AutoIncrement"])) return false;
			if (dbreadSql.GetSchemaTable().Rows[fldindex]["Expression"].ToString().Length > 0) return false;
			return true;
		}
		catch { return false; }
	}

	public int ReadCount { get { return ReadCt; } }
	public bool Eof { get { return eof; } }
	#endregion

	//===================================
	public object GetObject(string fieldname)
	{
		try { if (dbreadSql != null) return (dbreadSql[fieldname]); }
		catch { }
		return null;
	}
	public object GetObject(int index)
	{
		try { if (dbreadSql != null) return (dbreadSql[index]); }
		catch { }
		return null;
	}

	//return data converted to specified type, handle nulls and default values
	//===================================
	public string GetString(string fieldname) { return GetString(fieldname, ""); }
	public string GetString(string fieldname, string DefaultValue)
	{
		try { if (dbreadSql != null) return (dbreadSql[fieldname].ToString()); }
		catch { return DefaultValue; }
		return DefaultValue;
	}
	public string GetString(int index) { return GetString(index, ""); }
	public string GetString(int index, string DefaultValue)
	{
		try { if (dbreadSql != null) return (dbreadSql[index].ToString()); }
		catch { }
		return DefaultValue;
	}

	//===================================
	public string GetString(int index, string DefaultValue, string Mask)
	{
		try{
			Type t = dbreadSql.GetFieldType(index);
			if (t == typeof(string)){
				if (Mask == "<") return dbreadSql[index].ToString().ToLower();
				else if (Mask == ">") return dbreadSql[index].ToString().ToUpper();
				else return dbreadSql[index].ToString();
			}else if (t == typeof(Int16)){		//"INT";
				return Convert.ToInt16(dbreadSql[index]).ToString(Mask);
			} else if (t == typeof(long) || t == typeof(Int32)) {		//"LONG";
				return Convert.ToInt32(dbreadSql[index]).ToString(Mask);
			} else if (t == typeof(Single)) {		//"SINGLE";
				return Convert.ToSingle(dbreadSql[index]).ToString(Mask);
			} else if (t == typeof(double)) {		//"DOUBLE";
				return Convert.ToDouble(dbreadSql[index]).ToString(Mask);
			} else if (t == typeof(decimal)) {		//"DECIMAL";
				return Convert.ToDecimal(dbreadSql[index]).ToString(Mask);
			} else
				return dbreadSql[index].ToString();
		} catch { }
		return DefaultValue; 
	}

	//===================================
	public int GetInt(string fldname) { return GetInt(fldname, 0); }
	public int GetInt(string fldname, int DefaultValue)
	{
		try { if (dbreadSql != null) return Convert.ToInt32(dbreadSql[fldname]); }
		catch { }
		return DefaultValue;
	}

	public int GetInt(int index) { return GetInt(index, 0); }
	public int GetInt(int index, int DefaultValue)
	{
		try { if (dbreadSql != null) return Convert.ToInt32(dbreadSql[index]); }
		catch { }
		return DefaultValue;
	}

	//===================================
	public Single GetSingle(string fldname) { return GetSingle(fldname, (Single)0); }
	public Single GetSingle(string fldname, Single DefaultValue)
	{
		try { if (dbreadSql != null) return (Convert.ToSingle(dbreadSql[fldname])); }
		catch { }
		return DefaultValue;
	}

	public Single GetSingle(int index) { return GetSingle(index, (Single)0); }
	public Single GetSingle(int index, Single DefaultValue)
	{
		try { if (dbreadSql != null) return (Convert.ToSingle(dbreadSql[index])); }
		catch { }
		return DefaultValue;
	}

	//===================================
	public bool GetBool(string fldname) { return GetBool(fldname, false); }
	public bool GetBool(string fldname, bool DefaultValue)
	{
		try { if (dbreadSql != null) return Convert.ToBoolean(dbreadSql[fldname]); }
		catch { }
		return DefaultValue;
	}

	public bool GetBool(int index) { return GetBool(index, false); }
	public bool GetBool(int index, bool DefaultValue)
	{
		try { if (dbreadSql != null) return Convert.ToBoolean(dbreadSql[index]); }
		catch { }
		return DefaultValue;
	}

	//===================================
	public char GetChar(string fldname) { return GetChar(fldname, '\0'); }
	public char GetChar(string fldname, char DefaultValue)
	{
		try { if (dbreadSql != null) return (dbreadSql[fldname].ToString()[0]); }
		catch { }
		return DefaultValue;
	}

	public char GetChar(int index) { return GetChar(index, '\0'); }
	public char GetChar(int index, char DefaultValue)
	{
		try { if (dbreadSql != null) return (dbreadSql.GetString(index)[0]); }
		catch { }
		return DefaultValue;
	}

	//===================================
	public DateTime GetDateTime(string fldname) { return GetDateTime(fldname, DateTime.MinValue); }
	public DateTime GetDateTime(string fldname, DateTime DefaultValue)
	{
		try { if (dbreadSql != null) return Convert.ToDateTime(dbreadSql[fldname]); }
		catch { }
		return DefaultValue;
	}

	public DateTime GetDateTime(int index) { return GetDateTime(index, DateTime.MinValue); }
	public DateTime GetDateTime(int index, DateTime DefaultValue)
	{
		try { if (dbreadSql != null) return Convert.ToDateTime(dbreadSql[index]); }
		catch { }
		return DefaultValue;
	}

	public string GetDateTimeString(string fldname) { return GetDateTimeString(fldname, "", ""); }
	public string GetDateTimeString(string fldname, string mask) { return GetDateTimeString(fldname, mask, ""); }
	public string GetDateTimeString(string fldname, string mask, string DefaultValue)
	{
		try { if (dbreadSql != null) return Convert.ToDateTime(dbreadSql[fldname]).ToString(mask); }
		catch { }
		return DefaultValue;
	}

	//===================================
	public double GetDouble(string fldname) { return GetDouble(fldname, (double)0); }
	public double GetDouble(string fldname, double DefaultValue)
	{
		try { if (dbreadSql != null) return (Convert.ToDouble(dbreadSql[fldname])); }
		catch { }
		return DefaultValue;
	}

	public double GetDouble(int index) { return GetDouble(index, (double)0); }
	public double GetDouble(int index, double DefaultValue)
	{
		try { if (dbreadSql != null) return (Convert.ToDouble(dbreadSql[index])); }
		catch { }
		return DefaultValue;
	}

	//===================================
	public bool IsNull(int index)
	{
		try { if (dbreadSql != null) return (dbreadSql[index] == DBNull.Value); }
		catch { }
		return true;
	}

	public bool IsNull(string fldname)
	{
		try { if (dbreadSql != null) return (dbreadSql[fldname] == DBNull.Value); }
		catch { }
		return true;
	}

	//===================================
	public string TableName { get { return GetTableName(curSql); } }
	public string GetTableName(string sql)
	{
		string TableName = "";
		int n;

		if (sql.Substring(0, 7).Equals("SELECT ", StringComparison.OrdinalIgnoreCase)) {
			n = sql.IndexOf(" FROM ", 0, StringComparison.OrdinalIgnoreCase);
			if (n > 0) {
				sql = sql.Substring(n + 6).TrimStart();
				if (sql.StartsWith("["))
					n = sql.IndexOf(']');
				else if (sql.StartsWith("("))
					return "";	//complex table list or nested select
				else
					n = sql.IndexOf(' ');

				if (n > 0)
					TableName = sql.Substring(0, n + 1).TrimEnd();
				else
					TableName = sql;
			}
		}
		return TableName;
	}

	public int FieldCount{
		get {
			try { if (dbreadSql != null) return dbreadSql.VisibleFieldCount; }
			catch { }
			return 0;
		}
	}

	public string FieldName(int Index) {
		try { if (dbreadSql != null) return dbreadSql.GetName(Index); }
		catch { }
		return "";
	}

	public int FieldIndex(string FieldName) {
		if (dbreadSql == null) return 0; 
		for (int i = 0; i < dbreadSql.VisibleFieldCount; i++){
			if (dbreadSql.GetName(i).Equals(FieldName, StringComparison.OrdinalIgnoreCase))
				return i;
		}
		return -1;
	}

	public Type FieldType(int Index) {
		try { if (dbreadSql != null) return dbreadSql.GetFieldType(Index); }
		catch { }
		return null;
	}

	public string FieldTypeName(int Index) {
		try { if (dbreadSql != null) return dbreadSql.GetDataTypeName(Index); }
		catch { }
		return "";
	}
}
