﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public partial class Products : System.Web.UI.Page
{
	sqlDb db = new sqlDb();
	sqlDataset ds = new sqlDataset();
	HttpParms hParms = new HttpParms();

	string[] GRIDFIELDNAMES = new string[] { "Name", "ProductNumber", "Color", "SafetyStockLevel", "ReorderPoint", "StandardCost", "ListPrice" };

	//==================================================
	protected void Page_Load(object sender, EventArgs e)
	{
		//open the database for read or update
		string DbConnectionSpec = db.WebDBConnectionString("AdventureWorks");
		if (DbConnectionSpec.Length > 0)
			db.Open(DbConnectionSpec);

		if (!IsCallback) LoadPage();
	}

	//==================================================
	protected void Page_UnLoad(object sender, EventArgs e)
	{
		db.Close();
		db = null;
	}

	//==================================================
	public void LoadPage()
	{
		//get specs from URL
		int pg = hParms.GetQueryParmInt("pg", 1);
		int pglen = hParms.GetQueryParmInt("pglen", 25);
		int sort = hParms.GetQueryParmInt("sort", 0);
		string filter = hParms.GetQueryParm("filter", "");
		string search = hParms.GetQueryParm("find", "");

		//populate product grid

		//create sql query to get data for current grid view
		string sql = GetProductListSQL(ref pg, ref pglen, sort, filter, search);

		//populate the grid
		if (sql.Length > 0)
			db.BindRepeater(ref repProducts, sql);

		//update nav controls
		string url = Request.Url.ToString();
		btnPrev.HRef = hParms.SetUrlQueryParm(url, "pg", (pg - 1).ToString());
		btnNext.HRef = hParms.SetUrlQueryParm(url, "pg", (pg + 1).ToString());
		spnPageNbr.InnerText = pg.ToString();
	}

	//==================================================
	private string GetProductListSQL(ref int pg, ref int pglen, int sortCol, string filterSpec, string searchSpec)
	{
		//validate parms, then create sql to populate the products grid

		//---PAGE-----------------------------------------------
		if (pg < 1) pg = 1;
		if (pglen < 10) pglen = 10;

		int recordStart = (pg - 1) * pglen + 1;
		int recordEnd = recordStart + pglen;

		//---SORT-----------------------------------------------
		// "sort" indicates on which column the list is sorted. A negative value indicates sort descending.
		// ex. 1 means sort by first column, 2 = sort by second col, -2 = sort by second column descending

		bool SortDesc = (sortCol < 0);
		sortCol = Math.Abs(sortCol);

		
		// if sort = 0 (no sort selected) or is out of range, so use default sort (1st column)

		if (sortCol == 0 || sortCol > GRIDFIELDNAMES.Length)
		{
			sortCol = 1;	//default sort column
		}
		sortCol--;	//change sort spec to access 0-based array

		//---FILTER-----------------------------------------------
		//string filterSpec = "";

		//---SEARCH-----------------------------------------------
		//if (searchSpec.Trim().Length > 0)		{		}

		//---BUILD SQL-----------------------------------------------
		string sql = "SELECT * FROM (SELECT ROW_NUMBER() OVER ( ORDER BY " + GRIDFIELDNAMES[sortCol] + (SortDesc ? " DESC" : "") + " ) AS RowNum, "
			+ " Name, ProductNumber, Color, SafetyStockLevel, ReorderPoint, StandardCost, ListPrice, ProductID"
			+ " FROM Production.Product ";

		if (filterSpec.Length > 0){
			sql += " WHERE " + filterSpec;
		}

		sql += ") as dat1 WHERE RowNum >= " + recordStart.ToString()
			 + " AND RowNum < " + recordEnd.ToString()
			 + " ORDER BY RowNum";

		return sql.ToString();
	}

	//==================================================
	protected void repProducts_ItemDataBound(object sender, RepeaterItemEventArgs e)
	{
		if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
		{
			sqlDataset dat = new sqlDataset((System.Data.Common.DbDataRecord)(e.Item.DataItem));

			try{
				((HtmlInputText)e.Item.FindControl("t1")).Value = dat.GetString("Name");
				((HtmlInputText)e.Item.FindControl("t2")).Value = dat.GetString("ProductNumber");
				((HtmlInputText)e.Item.FindControl("t3")).Value = dat.GetString("Color");
				((HtmlInputText)e.Item.FindControl("t4")).Value = dat.GetInt("SafetyStockLevel").ToString();
				((HtmlInputText)e.Item.FindControl("t5")).Value = dat.GetInt("ReorderPoint").ToString();
				((HtmlInputText)e.Item.FindControl("t6")).Value = dat.GetDouble("StandardCost").ToString("0.00");
				((HtmlInputText)e.Item.FindControl("t7")).Value = dat.GetDouble("ListPrice").ToString("0.00");
				((Button)e.Item.FindControl("btnDel")).CommandArgument = dat.GetDouble("ProductID").ToString();
			}
			catch { }
		}
	}

	protected void repProducts_ItemCommand(object sender, RepeaterCommandEventArgs e)
	{
		switch (e.CommandName)
		{
			case "del":
				string sql = "DELETE FROM Production.Product WHERE ProductID = " + e.CommandArgument.ToString();
				db.Exec(sql);
				Response.Redirect(Request.Url.ToString());
				break;
		}
	}

	protected void btnAdd_Click(object sender, EventArgs e)
	{
		try
		{
			string name = ((HtmlInputText)FindControl("ta1")).Value;
			string prod = ((HtmlInputText)FindControl("ta2")).Value;
			string colr = ((HtmlInputText)FindControl("ta3")).Value;
			string stck = ((HtmlInputText)FindControl("ta4")).Value;
			string reord = ((HtmlInputText)FindControl("ta5")).Value;
			string cost = ((HtmlInputText)FindControl("ta6")).Value;
			string price = ((HtmlInputText)FindControl("ta7")).Value;

			string sql = "INSERT INTO Production.Product (Name, ProductNumber, Color, SafetyStockLevel, ReorderPoint, StandardCost, ListPrice)"
				+ " VALUES (" + db.TEXT(name, false, true, 50, true)
				+ ", " + db.TEXT(prod, false, true, 25, true)
				+ ", " + db.TEXT(prod, false, true, 15, true)
				+ ", " + CMath.CInt(stck, 0).ToString()
				+ ", " + CMath.CInt(reord, 0).ToString()
				+ ", " + CMath.CDouble(cost, 0).ToString()
				+ ", " + CMath.CDouble(price, 0).ToString() + ")";

			db.Exec(sql);
		}
		catch { }
	}
}