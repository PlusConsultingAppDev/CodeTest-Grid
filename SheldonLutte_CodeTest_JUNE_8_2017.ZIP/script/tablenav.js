﻿// Copyright © 2013-2015 One 2 Three, Inc. All rights reserved. Duplication, distribution and adaptation are not permitted.
// Author: Sheldon Lutte - By contract, the intellectual property and technology of this work is solely owned by One 2 Three, Inc. Crate and Barrel has exclusive, non-transferable right to use and modify this code for internal use for an unlimited period of time.

var timRepaint = 0;
var hidClass = "prc";
var CurFocusEl = null;
//var tnCurFocusObj = null;		//handle to last object to receive focus
//var tnCurEditObj = null;		//handle to last object to receive edits
function tnKeydown(e, mode) {
	//get object receiving this event
	e = e || window.event;
	var el = e.target || e.srcElement;

	//get key pressed
	var kcode;
	if (window.event)
		kcode = (e.charCode ? e.charCode : e.keyCode);	//IE
	else
		kcode = e.which;	//firefox

	switch (kcode) {
		case 113: 	//F2 (edit)
			setCaretPos(el, (el.innerText || el.value).length);
			e.cancelBubble = true;
			e.stopPropagation();
			return false;

		case 13: 	//return
			if (el.tagName == 'TEXTAREA') {
				if (e.shiftKey) {
					//var txt = el.innerText.replace(/\r\n/g, "\r");
					var txt = el.value.replace(/\r\n/g, "\r");
					var i = getCaretPos(el).start, j = getCaretPos(el).end;
					//el.innerText = txt.substr(0, i) + "¶" + txt.substr(j);
					el.value = txt.substr(0, i) + "¶" + txt.substr(j);
					setCaretPos(el, i + 1);
					e.keyCode = 0;
					event.cancelBubble = true;
					event.stopPropagation();
					if (timRepaint) clearTimeout(timRepaint);
					timRepaint = setTimeout(function () { echoValueObj(el); }, 50);
					return false;
					//return true;
				}
			}
			else {
				el = tnFocusOffsetElement(el, 0, 1);
				e.keycode = 0;
				return false;
				return true;
			}
			break;

		case 27: 	//esc
			break;

		case 38: 	//up arrow
		case 40: 	//down arrow
			if (!e.shiftKey) {
				var offset = (kcode == 38 ? -1 : 1);
				if (el.tagName == "TEXTAREA") {
					cp = getCaretPos(el);
					//if all text selected, go to next/prev cell now
					if ((cp.end - cp.start) == el.innerText.replace(new RegExp("\r\n", 'g'), "\r").length) {
						e.keyCode = 0;
						goToOffsetRow(el, offset, -1);
						e.cancelBubble = true;
						e.stopPropagation();
						return false;
						//return true;
					}
					else {
						//allow keydown action to move cursor, then if caret didn't move, go to next/prev cell instead
						setTimeout(function () { goToOffsetRow(el, offset, cp.start); }, 1);
						return true;
					}
				}
					//for input control, up/down key goes to next/prev cell immediately
				else if (el.tagName == "INPUT") {
					goToOffsetRow(el, offset, -1);
					e.keyCode = 0;
					e.cancelBubble = true;
					e.stopPropagation();
					return false;
					//return true;
				}
			}
			break;

		case 37: 	//left arrow 
		case 39: 	//right arrow
			if (!e.shiftKey) {
				var offset = (kcode == 37 ? -1 : 1);
				if (el.tagName == "TEXTAREA") {
					cp = getCaretPos(el);
					//if all text selected, go to next/prev cell now
					if ((cp.end - cp.start) == el.innerText.replace(new RegExp("\r\n", 'g'), "\r").length) {
						e.keyCode = 0;
						if (mode == 2) {
							deselect();
							if (kcode == 37) setCaretPos(el, 0);
							else setCaretPos(el, el.innerText.length);
							return false;
						} else {
							goToOffsetCol(el, offset, -1);
							e.cancelBubble = true;
							e.stopPropagation();
							return false;
						}
					}
					else {
						//allow keydown action to move cursor, then if caret didn't move, go to next/prev cell instead
						setTimeout(function () { goToOffsetCol(el, offset, cp.start); }, 1);
						return true;
					}
				}
					//for input control, up/down key goes to next/prev cell immediately
				else if (el.tagName == "INPUT") {
					cp = getCaretPos(el);
					//if all text selected, go to next/prev cell now
					if ((cp.end - cp.start) == el.value.replace(new RegExp("\r\n", 'g'), "\r").length) {
						if (mode == 2) {
							deselect();
							if (kcode == 37) setCaretPos(el, 0);
							else setCaretPos(el, el.value.length);
							return false;
						} else {
							goToOffsetCol(el, offset, -1);
							e.keyCode = 0;
							e.cancelBubble = true;
							e.stopPropagation();
							return false;
						}
					}
				}
			}

			//getCaretRow(el);
			//document.getElementById("cp").innerHTML = taCpLine;
			//return true;
			break;
	}

	//NOTE: 3rd parm of this function kicks off a 1ms timer to allow textarea to paint before resizing. This allows us to do this during keydown event
	//if (el.tagName == "TEXTAREA") autosizeTextarea(el, 18, 10);
	if (kcode > 31 || kcode == 13 || kcode == 10 || kcode == 8) {
		if (el.tagName == "TEXTAREA") {
			setTimeout(function () { autosizeTextarea(el); }, 0);
			if (timRepaint) clearTimeout(timRepaint);
			timRepaint = setTimeout(function () { echoValueObj(el); }, 50);
		} else if (el.tagName == "INPUT" && (el.getAttribute("type") == "text" || el.getAttribute("type") == "password")) {
			if (timRepaint) clearTimeout(timRepaint);
			timRepaint = setTimeout(function () { echoValueObj(el); }, 50);
		}
	}

	return true;
}

function tnClick(e) {
	e = e || window.event;
	el = e.target || e.srcElement;	//record which object is receiving input
	tnOnFocus(el);
	if (el.tagName == "INPUT" && (el.getAttribute("type") == "checkbox" || el.getAttribute("type") == "radio")){
		if (timRepaint) clearTimeout(timRepaint);
		timRepaint = setTimeout(function () { echoValueObj(el); }, 50);
	}
}

function tnFocusOffsetElement(el, cx, cy) {
	el = getTableOffsetElement(el, cx, cy);
	if (el) el.focus();
	return el;
}

function tnOnFocusEvent(e) {
	e = e || window.event;
	var el = e.target || e.srcElement;
	tnOnFocus(el);
}

function tnOnFocus(el) {
	//e = e || window.event;
	//var el = e.target || e.srcElement;
	if (el == CurFocusEl) return;
	CurFocusEl = el;
	if (el.tagName == "TEXTAREA")
		el.select();
	else if (el.tagName == "INPUT") {
		//if (el.getAttribute("type") == "checkbox")
		//	el.deselect();
		//else
		if (el.getAttribute("type") == "text" || el.getAttribute("type") == "password")
			el.select();
	}
	highlightSignField(el);
}

function goToOffsetRow(el, offset, c) {
	try {
		//if caret didn't move or c==-1 indicates go now
		if (c == -1 || c == getCaretPos(el).start){
			var el2 = getTableOffsetElement(el, 0, (offset < 0 ? -1 : 1));
			if (el2 == null) return;
			el2.focus();
			highlightSignField(el2);
			//setTimeout(function () { el.select(); }, 5);
			tnOnFocus(el2);
			//if (obj.tagName == "INPUT") {
			//	if (obj.getAttribute("type") == "checkbox") obj.deselect(); else obj.select();
			//} else if (obj.tagName == "TEXTAREA") obj.select();
			//highlightSignField(obj);
		}
	} catch (er) { }
}

function goToOffsetCol(el, offset, c) {
	try {
		//if caret didn't move or c==-1 indicates go now
		if (c == -1 || c == getCaretPos(el).start) {
			var el2 = getTableOffsetElement(el, (offset < 0 ? -1 : 1), 0);
			if (el2 == null) return;
			el2.focus();
			highlightSignField(el2);
			//setTimeout(function () { el.select(); }, 5);
			tnOnFocus(el2);
			//if (obj.tagName == "INPUT") {
			//	if (obj.getAttribute("type") == "checkbox") obj.deselect(); else obj.select();
			//} else if (obj.tagName == "TEXTAREA") obj.select();
			//highlightSignField(obj);
		}
	} catch (er) { }
}

function highlightSignField(el) {
	clearClassAll(document.getElementById("dEditPreview"), "sel");
	//get object in sign preview
	var id = el.getAttribute("rel");
	if (id == null || id == '') return;
	var el2 = document.getElementById(id);
	if (el2 == null) return;
	addClass(el2, "sel");
}

function getTableOffsetElement(el, cx, cy) {
	var obj = el;
	while (obj != null && obj.tagName != "TD" && obj.tagName != "TH") obj = obj.parentNode;
	if (obj == null) return;

	//count number of siblings preceeding current cell
	var i, cx2 = 0;
	var cell1 = obj;
	while (cell1 != null && cell1.previousSibling != null) {
		cell1 = cell1.previousSibling;
		if (cell1.tagName == "TH" || cell1.tagName == "TD") cx2++;
	}

	//go to specified row via cy offset
	if (cy != 0) {
		obj = obj.parentNode;	//TR
		while (cy < 0){
			if (obj.previousSibling == null) break;
			obj = obj.previousSibling;
			if (obj.tagName == "TR" && (hidClass == "" || obj.className != hidClass)) cy++;
		}
		while (cy > 0) {
			if (obj.nextSibling == null) break;
			obj = obj.nextSibling;
			if (obj.tagName == "TR" && (hidClass == "" || obj.className != hidClass)) cy--;
		}
		cx = cx2 + cx;
		obj = obj.firstChild;
		while (obj != null && obj.tagName != "TH" && obj.tagName != "TD") obj = obj.nextSibling;
		if (obj == null) return null;
	}

	//go to specified cell via cx offset
	while (cx < 0) {
		if (obj.previousSibling == null) break;
		obj = obj.previousSibling;
		if (obj.tagName == "TH" || obj.tagName == "TD") cx++;
	}
	while (cx > 0) {
		if (obj.nextSibling == null) break;
		obj = obj.nextSibling;
		if (obj.tagName == "TH" || obj.tagName == "TD") cx--;
	}

	//find 1st element in cell
	obj = obj.firstChild;
	while (obj != null) {
		if (obj.tagName == "INPUT" || obj.tagName == "TEXTAREA") break;
		obj = obj.nextSibling;
		if (obj == null) break;
	}
	return obj;
}

function autosizeTextarea(ta) {
	//set the textarea to full height by setting it's outer height = scroll height
	//NOTE: MUST set height to AUTO first
	//NOTE: ADD 18px for 1 blank line at bottom to prevent "bump" effect when wrapping to new line
	ta.style.height = 'auto';
	ta.style.height = (ta.scrollHeight + 18).toString() + 'px';
}

function autosizeAllTextarea(d) {
	var i, ta = d.getElementsByTagName("TEXTAREA");
	for (i = 0; i < ta.length; i++) autosizeTextarea(ta[i]);
}

//function tnEcho(e) {
//	e = e || window.event;
//	var o = e.target || e.srcElement;
//	var a = o.getAttribute("rel");
//	var s = document.getElementById(a);
//	if (s) s.innerText = o.value;
//}

function tnEcho(e) {
	e = e || window.event;
	var o = e.target || e.srcElement;
	echoValueObj(o);
}
function echoValueObj(o) {
	var id = o.getAttribute("rel");
	if (id == null || id == '') return;
	var el = document.getElementById(id);
	if (el == null) return;

	var txt = getElementText(o);

	//special fixes for turkish characters
	while (txt.indexOf("\\i") > -1) txt = txt.replace("\\i", "ı");		//&#304;
	while (txt.indexOf("\\I") > -1) txt = txt.replace("\\I", "İ");		//&#305;

	var fmt = o.getAttribute("fmt");
	var AsHtml = false;

	if (fmt != null && fmt.length > 0) {
		//boolean values
		if (o.getAttribute("type") == "checkbox" || o.getAttribute("type") == "radio") {
			txt = formatBoolEx(txt, fmt);
			AsHtml = true;

			//text values
		} else if (fmt == "sku") {
			txt = formatSku(txt);

		} else {
			//if (fmt.indexOf('$') > -1)
			txt = formatEx(txt, fmt);
			//else
			//	el.innerText = formatEx(txt, fmt);
			AsHtml = true;
		}
	}

	fmt = o.getAttribute("fmtList");
	if (fmt != null && fmt != "") {
		txt = formatBullets(txt);
		if (el.tagName == "UL") txt = txt.substr(4, txt.length - 9);
		AsHtml = true;
	}

	if (AsHtml) el.innerHTML = txt; else setElementText(el, txt);
}

function initFieldSizes(d) {
	var i, t = d.getElementsByTagName('TEXTAREA');
	for (i = 0; i < t.length; i++) { autosizeTextarea(t[i]); }
}
